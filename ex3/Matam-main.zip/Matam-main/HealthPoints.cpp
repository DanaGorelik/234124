#include "HealthPoints.h"
#include <iostream>

HealthPoints::HealthPoints(int maxPoints) :
        m_HP(maxPoints), m_maxHP(maxPoints)
{
    if (maxPoints <= 0) {
        throw InvalidArgument();
    }
}

HealthPoints operator+(int numPoints, HealthPoints healthPoints)  {
    return healthPoints + numPoints;
//    HealthPoints res=healthPoints;
//    res+=numPoints;
//    return res;
}


HealthPoints HealthPoints::operator+(int numPoints) {
    return (*this)+= numPoints;
}


HealthPoints operator-(HealthPoints healthPoints,int numPoints)  {
    return healthPoints+((-1)*numPoints);
}

HealthPoints& HealthPoints::operator+=(int numPoints) {
    if (this->m_HP+numPoints > this->m_maxHP) {
        this->m_HP = this->m_maxHP;
    }
    else if (this->m_HP+numPoints < 0) {
        this->m_HP = 0;
    }
    else
        this->m_HP+=numPoints;
    return *this;
}

HealthPoints& HealthPoints::operator-=(int numPoints) {
    return operator+=((-1)*numPoints);
}

HealthPoints& HealthPoints::operator=(const HealthPoints &hp) {
    m_HP = hp.m_HP;
    m_maxHP=hp.m_maxHP;
    return *this;
}

bool operator>(const HealthPoints &a, const HealthPoints &b) {
    if (a.m_HP > b.m_HP) {
        return true;
    }
    return false;
}
bool operator==(const HealthPoints &a, const HealthPoints &b) {
    if (!(a > b) && !(b > a)) {
        return true;
    }
    return false;
}

bool operator!=(const HealthPoints &a, const HealthPoints &b) {
    if (!(a==b)) {
        return true;
    }
    return false;
}

bool operator>=(const HealthPoints &a, const HealthPoints &b) {
    if ((a > b) || (a == b)) {
        return true;
    }
    return false;
}

bool operator<=(const HealthPoints &a, const HealthPoints &b) {
    if (!(a > b) || (a == b)) {
        return true;
    }
    return false;
}

bool operator<(const HealthPoints &a, const HealthPoints &b) {
    if (!(a >= b)) {
        return true;
    }
    return false;
}

std::ostream& operator<<(std::ostream& os, const HealthPoints& healthPoints) {
    os << healthPoints.m_HP;
    os << "(" << healthPoints.m_maxHP << ")";
    return os;
}
