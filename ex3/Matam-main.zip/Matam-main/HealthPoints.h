//
// Created by Shaked on 24/05/2022.
//

#ifndef EX3_HEALTHPOINTS_H
#define EX3_HEALTHPOINTS_H
#include <iostream>


class HealthPoints {

public:
    HealthPoints(int maxPoints = 100);
    HealthPoints(const HealthPoints&)=default;
    ~HealthPoints() = default;

//    HealthPoints(const int numPoints);
    friend HealthPoints operator+(int numPoints, HealthPoints p);
    HealthPoints operator+(int numPoints);

    friend HealthPoints operator-(HealthPoints p, int numPoints);


    HealthPoints& operator+=(int numPoints);
    HealthPoints& operator-=(int numPoints);
    HealthPoints& operator=(const HealthPoints& hp);
    //HealthPoints& operator=(int numPoints);

    friend bool operator==(const HealthPoints &a, const HealthPoints &b);
    friend bool operator>(const HealthPoints &a, const HealthPoints &b);
    friend bool operator<(const HealthPoints &a, const HealthPoints &b);
    friend std::ostream& operator<<(std::ostream& os, const HealthPoints& healthPoints);

    class InvalidArgument : public std::exception {};

private:
    int m_HP;
    int m_maxHP;

};
//
//HealthPoints operator+(HealthPoints p, int numPoints);
//HealthPoints operator-(HealthPoints p, int numPoints);

#endif //EX3_HEALTHPOINTS_H
