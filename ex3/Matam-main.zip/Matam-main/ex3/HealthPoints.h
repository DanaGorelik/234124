#ifndef EX3_HEALTHPOINTS_H
#define EX3_HEALTHPOINTS_H
#include <iostream>
#define MAX_HP 100

class HealthPoints {

public:
    HealthPoints(int maxHP = MAX_HP);
    HealthPoints(const HealthPoints& healthPoints) = default;
    ~HealthPoints() = default;

     friend HealthPoints operator+(int HP, HealthPoints hp);
    HealthPoints operator+(int HP);
    friend HealthPoints operator-(HealthPoints healthPoints, int HP);
    HealthPoints& operator+=(int HP);
    HealthPoints& operator-=(int HP);
    HealthPoints& operator=(const HealthPoints& hp);

    bool operator>(const HealthPoints &a) const;

    friend std::ostream& operator<<(std::ostream& os, const HealthPoints& hp);

    class InvalidArgument : public std::exception {};

private:
    int m_HP;
    int m_maxHP;

};

bool operator==(const HealthPoints &hp1, const HealthPoints &hp2);
bool operator!=(const HealthPoints &hp1, const HealthPoints &hp2);
bool operator>=(const HealthPoints &hp1, const HealthPoints &hp2);
bool operator<=(const HealthPoints &hp1, const HealthPoints &hp2);
bool operator<(const HealthPoints &hp1, const HealthPoints &hp2);

#endif //EX3_HEALTHPOINTS_H
