//
// Created by DELL on 25-May-22.
//
#include "HealthPoints.h"
int main()
{
    HealthPoints hp1=1;

    hp1 += 1;


    HealthPoints hp2 = 80085;

    hp2 -= 80000;

    hp2 -= 80;


    hp2 -= 80;


    hp2 -= 1;


    hp2 += 1;

    hp2 += 80;

    hp2 += 8000;


    hp2 += 80000;

    hp2 -= 3;

    hp2 += 3;


    hp2 -= 80085;


    hp1 = hp2 + 100;


    hp1 = hp1 - 1;

    hp1 = hp1 - 1;


    hp1 = hp1 + 1;


    hp1 = hp1 + 1;


    hp1 = 1 + hp1;


    hp1 = 1 + hp1;


    hp1 = hp2 + 90000;


    hp1 = 90000 + hp2;


    hp2 = hp1 - 80000;

    hp1 = hp2 - 90000;


    hp1 = hp2 + (-2);
//    helperReadHP(hp1, result);
//    REQUIRE(result == "83(80085)");

    hp1 = (-84) + hp2;
//    helperReadHP(hp1, result);
//    REQUIRE(result == "1(80085)");


    return 0;
}