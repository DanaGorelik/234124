template<class T>
typename Queue<T>::Iterator Queue<T>::Iterator::operator++(int) {
    Queue<T>::Iterator result = *this;
    if (result == nullptr) {
        throw InvalidOperation();
    }
    ++(*this);

    return result;
}