#include "HealthPoints.h"
#include <iostream>
#define MINUS -1

//Implementation of the constructor of the HealthPoints class.
HealthPoints::HealthPoints(int maxHP) :
        m_HP(maxHP), m_maxHP(maxHP)
{
    if (maxHP <= 0) {
        throw InvalidArgument();
    }
}

/////////////Arithmetic operators/////////////

//Definition of operator +, friend function of the class.
// Calls operator+=
HealthPoints operator+(int HP, HealthPoints hp)  {
    HealthPoints result = hp;
    result += HP;
    return result;
}

//Definition of operator + in HealthPoint class.
// Calls operator+(int HP, HealthPoints hp)
HealthPoints HealthPoints::operator+(int HP) {
    return HP+(*this);
}

//Definition of operator -, friend function of the class.
//Calls operator+ with -1*HP
HealthPoints operator-(HealthPoints healthPoints, int HP)  {
    return healthPoints+((MINUS)*HP);
}

//Definition of operator += in HealthPoint class.
//Checks whether the amount of HP exceeds the max HP or goes below zero
HealthPoints& HealthPoints::operator+=(int HP) {
    if (this->m_HP+HP > this->m_maxHP) {
        this->m_HP = this->m_maxHP;
    }
    else if (this->m_HP+HP < 0) {
        this->m_HP = 0;
    }
    else
        this->m_HP+=HP;
    return *this;
}

//Definition of operator -= in HealthPoint class.
// Calls operator+= with -1*HP
HealthPoints& HealthPoints::operator-=(int HP) {
    return operator+=((MINUS)*HP);
}

//Definition of operator = in HealthPoint class.
HealthPoints& HealthPoints::operator=(const HealthPoints &hp) {
    m_HP = hp.m_HP;
    m_maxHP = hp.m_maxHP;
    return *this;
}

/////////////Boolean operators/////////////

//Definition of operator > in HealthPoint class.
bool HealthPoints::operator>(const HealthPoints &hp1) const {
    if (this->m_HP > hp1.m_HP) {
        return true;
    }
    return false;
}

//Definition of operator ==, based on the member function of operator >.
bool operator==(const HealthPoints &hp1, const HealthPoints &hp2) {
    if (!(hp1 > hp2) && !(hp2 > hp1)) {
        return true;
    }
    return false;
}

//Definition of operator !=, based on operator ==.
bool operator!=(const HealthPoints &hp1, const HealthPoints &hp2) {
    if (!(hp1==hp2)) {
        return true;
    }
    return false;
}

//Definition of operator >=, based on operator == and operator >.
bool operator>=(const HealthPoints &hp1, const HealthPoints &hp2) {
    if ((hp1 > hp2) || (hp1 == hp2)) {
        return true;
    }
    return false;
}

//Definition of operator <=, based on operator == and operator >.
bool operator<=(const HealthPoints &hp1, const HealthPoints &hp2) {
    if (!(hp1 > hp2) || (hp1 == hp2)) {
        return true;
    }
    return false;
}

//Definition of operator <, based on operator >=.
bool operator<(const HealthPoints &hp1, const HealthPoints &hp2) {
    if (!(hp1 >= hp2)) {
        return true;
    }
    return false;
}

/////////////Print operator/////////////
// Print operator for printing instances of a class in a convenient way.
std::ostream& operator<<(std::ostream& os, const HealthPoints& healthPoints) {
    os << healthPoints.m_HP;
    os << "(" << healthPoints.m_maxHP << ")";
    return os;
}