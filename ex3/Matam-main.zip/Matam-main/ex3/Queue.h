#ifndef HEALTHPOINTS_CPP_QUEUE_H
#define HEALTHPOINTS_CPP_QUEUE_H

#include <new>

//////////////Class Queue//////////////

template<class T>
class Queue {
public:
    class Iterator;
    class ConstIterator;

    Iterator begin();
    ConstIterator begin() const;
    Iterator end();
    ConstIterator end() const;

    class EmptyQueue {};

    Queue();
    Queue(const Queue &queueToCopy);
    ~Queue();

    Queue& operator=(const Queue& queue);

    void pushBack(const T &data);
    T& front();
    const T& front() const;
    void popFront();
    int size() const;

private:
    class Node;
    Node *m_head, *m_tail;
};

//////////////Class Node//////////////

template <class T>
class Queue<T>::Node {
public:
    explicit Node(T data);
    Node(const Node& a);
    ~Node() = default;
    Queue<T>::Node& operator=(const Queue<T>::Node& node);
    bool operator==(const Node& node) const;
    T m_data;
    Node* m_next;
};

//////////////Class Iterator//////////////

template <class T>
class Queue<T>::Iterator {
public:
    class InvalidOperation {};
    Iterator(const Iterator &);
    ~Iterator();
    Iterator &operator++();
    Iterator operator++(int);
    bool operator!=(const Iterator &i) const;
    bool operator==(const Iterator &i) const;
    T &operator*();
    Iterator &operator=(const Iterator &) = default;
private:
    Node *m_node;
    explicit Iterator(Node *node);
    friend class Queue<T>;
};

//////////////Class ConstIterator//////////////

template <class T>
class Queue<T>::ConstIterator {
public:
    class InvalidOperation {};
    ConstIterator(const ConstIterator &);
    ~ConstIterator();
    const T& operator*() const;
    ConstIterator &operator++();
    ConstIterator operator++(int);
    bool operator!=(const ConstIterator &i) const;
    ConstIterator &operator=(const ConstIterator &) = default;
private:
    const Node *m_node;
    explicit ConstIterator(const Node *node);
    friend class Queue<T>;
};

//////////////filter and transform functions//////////////

//Implementation of filter function, which returns a new list according to a given condition.
template <class T, class Condition>
Queue<T> filter(const Queue<T>& queue, Condition condition) {
    Queue<T> result;
    for (T value: queue) {
        if (condition(value)) {
            try {
                result.pushBack(value);
            }
            catch (std::bad_alloc& badAlloc)
            {
                int resultSize = result.size();
                while (resultSize > 0)
                {
                    result.popFront();
                    resultSize--;
                }
            }

        }
    }
    return result;
}

//Implementation of transform function,
// which changes each one of the nodes of the queue according to a given operation.
template<class Operation, class T>
void transform(Queue<T>& queue, Operation operation) {
    for (T &value: queue) {
        operation(value);
    }
}

//////////////Queue Functions//////////////

//Implementation of the constructor of the Queue class.
template<class T>
Queue<T>::Queue() :
        m_head(nullptr), m_tail(nullptr)
{}

//Implementation of the copy constructor of the Queue class.
//Deletes the assigned queue in case of memory extension.
template<class T>
Queue<T>::Queue(const Queue &queueToCopy) {
    m_head = nullptr;
    m_tail = nullptr;
    int sizeCopy = queueToCopy.size();
    if (sizeCopy <= 0)
    {
        return;
    }
    Node *tmp = queueToCopy.m_head;
    try {
        while (sizeCopy > 0) {
            pushBack(tmp->m_data);
            tmp = tmp->m_next;
            sizeCopy--;
        }
        m_tail = queueToCopy.m_tail;
    }
    catch(std::bad_alloc& badAlloc) {
        while (m_head != nullptr)
        {
            popFront();
        }
        throw;
    }
}

//Implementation of the destructor of the Queue class.
template<class T>
Queue<T>::~Queue() {
    int queue_size = this->size();
    while (queue_size > 0)
    {
        popFront();
        queue_size--;
    }
}

// Implementation of assignment operator of the Queue class
// Copies the queue to a temporary queue, if the copying succeeds, completes the copy assignment.
// In case of memory extension, deletes the temporary queue
template<class T>
Queue<T>& Queue<T>::operator=(const Queue<T>& queue) {
    if (this == &queue)     {
        return *this;
    }
    if (queue.m_head == nullptr)     {
        m_head = nullptr;
        return *this;
    }
    Queue<T> newQueue; //Temporary element
    newQueue.pushBack(queue.m_head->m_data);
    try {
        for (T value : queue)         {
            newQueue.pushBack(value);
        }
    }
    catch (std:: bad_alloc& badAlloc)     {
        while (newQueue.m_head!= nullptr)         {
            newQueue.popFront();
        }
        throw;
    }
    while (m_head!= nullptr)     {
        popFront();
    }
    Node* saveHead = newQueue.m_head;
    m_head = saveHead->m_next;
    newQueue.m_head->m_next = nullptr;
    while (newQueue.m_head != nullptr)     {
        newQueue.popFront();
    }
    return *this;
}

//Implementation of pushBack function,
// which adds a new element (node) to the end of the queue (list).
template<class T>
void Queue<T>::pushBack(const T &data) {

    Node *tmp = new Node(data);
    if (m_head == nullptr) {
        m_head = tmp;
        m_tail = tmp;
    } else {
        m_tail->m_next = tmp;
        m_tail = m_tail->m_next;
    }
}

//Implementation of front function, which returns the first element (Node) of the queue (list).
//Throws an exception if the queue is empty.
template<class T>
T& Queue<T>::front() {
    if(m_head == nullptr) {
        throw EmptyQueue();
    }
    return m_head->m_data;
}

//Another implementation of front function for const variables.
template<class T>
const T& Queue<T>::front() const {
    if(m_head == nullptr) {
        throw EmptyQueue();
    }
    return m_head->m_data;
}

//Implementation of popFront function,
// which deletes the first element (node) from the queue (list).
// Throws an exception if the queue is empty.
template<class T>
void Queue<T>::popFront() {
    if (this->m_head == nullptr) {
        throw EmptyQueue();
    }
    Node *tmp = m_head;
    m_head = m_head->m_next;
    if (m_head == nullptr)
        m_tail = nullptr;
    delete(tmp);
}

//Implementation of size function,
// which counts the amount of elements (nodes) in the queue (list).
template<class T>
int Queue<T>::size() const{
    if(m_head == nullptr) {
        return 0;
    }
    int counter = 0;
    Node *tmp = m_head;
    while(tmp != nullptr) {
        counter++;
        tmp = tmp->m_next;
    }
    delete(tmp);
    return counter;
}

template<class T>
typename Queue<T>::Iterator Queue<T>::begin() {
    return Iterator(m_head);
}

template<class T>
typename Queue<T>::Iterator Queue<T>::end() {
    return Iterator(nullptr);
}

//For const queues.
template<class T>
typename Queue<T>::ConstIterator Queue<T>::begin() const {
    return ConstIterator(m_head);
}

//For const queues.
template<class T>
typename Queue<T>::ConstIterator Queue<T>::end() const {
    return ConstIterator(nullptr);
}

//////////////Node Functions//////////////

//Implementation of the constructor of the Node class.
template<class T>
Queue<T>::Node:: Node(T data):
        m_data(data), m_next(nullptr)
{}

//Implementation of the copy constructor of the Node class.
template<class T>
Queue<T>::Node:: Node(const Node& a) {
    m_data = a.m_data;
    m_next = a.m_next;
}

//Implementation of the assignment operator of the Node class.
template<class T>
typename Queue<T>::Node& Queue<T>::Node::operator=(const Queue<T>::Node &node) {
    if (this == &node) {
        return *this;
    }
    m_data = node.m_data;
    m_next = node.m_next;
    return *this;
}

//Implementation of the Operator== for comparing between two nodes.
template<class T>
bool Queue<T>::Node::operator==(const Queue<T>::Node &node) const {
    return (m_data == node.m_data);
}

//////////////Iterator Functions//////////////

//Implementation of the constructor of the Iterator class.
template<class T>
Queue<T>::Iterator::Iterator(Queue<T>::Node *node) :
        m_node(node) {
    if(m_node != node) {
        throw;
    }
}

//Implementation of the copy constructor of the Iterator class.
template<class T>
Queue<T>::Iterator::Iterator(const Iterator &) = default;

//Implementation of the destructor of the Iterator class.
template<class T>
Queue<T>::Iterator:: ~Iterator() = default;


template<class T>
typename Queue<T>::Iterator &Queue<T>::Iterator::operator++() {
    if (m_node == nullptr) {
        throw InvalidOperation();
    }
    m_node = m_node->m_next;
    return *this;
}

template<class T>
bool Queue<T>::Iterator::operator!=(const Iterator &iterator) const {
    return !(this->m_node == iterator.m_node);
}

template<class T>
bool Queue<T>::Iterator::operator==(const Iterator &iterator) const {
    return (this->m_node == iterator.m_node);
}

template<class T>
T &Queue<T>::Iterator::operator*() {
    if (m_node == nullptr) {
        throw InvalidOperation();
    }
    return m_node->m_data;
}

//////////////ConstIterator Functions//////////////

//Implementation of the constructor of the ConstIterator class.
template<class T>
Queue<T>::ConstIterator::ConstIterator(const Node *node) :
        m_node(node) {
    if (m_node != node) {
        throw;
    }
}

//Implementation of the copy constructor of the ConstIterator class.
template<class T>
Queue<T>::ConstIterator::ConstIterator(const ConstIterator &) = default;

//Implementation of the destructor of the ConstIterator class.
template<class T>
Queue<T>::ConstIterator:: ~ConstIterator() = default;


template<class T>
typename Queue<T>::ConstIterator &Queue<T>::ConstIterator::operator++() {
    if (m_node == nullptr)
    {
        throw InvalidOperation();
    }
    m_node = m_node->m_next;
    return *this;
}

template<class T>
typename Queue<T>::ConstIterator Queue<T>::ConstIterator::operator++(int) {
    const Queue<T>::ConstIterator result = *this;
    if (result == nullptr)
    {
        throw  InvalidOperation();
    }
    ++(*this);
    return result;
}

template<class T>
const T& Queue<T>::ConstIterator::operator*() const {
    if (m_node == nullptr)
    {
        throw InvalidOperation();
    }
    return m_node->m_data;
}

template<class T>
bool Queue<T>::ConstIterator::operator!=(const Queue<T>::ConstIterator &i) const  {
    return !(this->m_node==i.m_node);
}


#endif //HEALTHPOINTS_CPP_QUEUE_H