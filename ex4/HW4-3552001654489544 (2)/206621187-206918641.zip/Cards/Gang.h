#ifndef MTMCHKIN_CPP_GANG_H
#define MTMCHKIN_CPP_GANG_H

#include <queue>
#include <memory>

#include "BattleCards.h"
#include "Goblin.h"
#include "Vampire.h"
#include "Dragon.h"

class Gang : public Card {
public:
    Gang(std::vector<std::string> m_monsters);
    ~Gang() override = default;

    bool playCard(std::unique_ptr<Player> &player, bool gangMode, bool hasWon) override;
    void createGangCard(std::vector<std::string> &m_monsters);
    void printInheritance(std::ostream& os) const override;

private:
    std::vector<std::unique_ptr<BattleCards>> m_gang;
};


#endif //MTMCHKIN_CPP_GANG_H
