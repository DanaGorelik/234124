#include "BattleCards.h"
#define SINGLE_FORCE -1

BattleCards::BattleCards(std::string name, int force, int loot, int damage) :
Card(name),
m_force(force),
m_loot(loot),
m_damage(damage)
{}

void BattleCards::playCard(std::unique_ptr<Card> &card, std::unique_ptr<Player> &player) {
    if((player->getAttackStrength()) >= m_force) {
      player->levelUp();
       player->addCoins(m_loot);

       printWinBattle(player->getName(), getName(m_name));
    }
    else {
        player->damage(m_damage);
if (getName(m_name) == "Vampire") {
    player->buff(SINGLE_FORCE);
}
printLossBattle(player->getName(), getName(m_name));
    }
//    std::cout << *player <<std::endl;
}

std::string BattleCards::getName(std::string &name) {
    if (name == "Goblin") {
        return "Goblin";
    }
    if (name == "Vampire") {
        return "Vampire";
    }
    if (name == "Dragon") {
        return "Dragon";
    } else
        return " ";
    //////exception
}




