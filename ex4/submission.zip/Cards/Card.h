#ifndef EX4_CARD_H
#define EX4_CARD_H

#include "../Players/Player.h"
#include "../utilities.h"

//enum class cardName {Goblin, Vampire, Dragon, Merchant, Treasure, Pitfall, Barfight, Fairy}; // The name of the Card

class Card {
public:
    explicit Card(std::string name);
    virtual ~Card() = default;
    virtual void playCard(std::unique_ptr<Card> &card, std::unique_ptr<Player> &player) = 0;
    std::string getName() const;
     friend std::ostream& operator<<(std::ostream& os, const Card& card) ;

protected:
    std::string m_name;
};

#endif //EX4_CARD_H
