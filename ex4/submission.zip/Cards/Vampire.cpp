#include "Vampire.h"
#define FORCE_NUM 10
#define LOOT_COINS_NUM 2
#define DAMAGE_NUM 10

Vampire::Vampire() :
        BattleCards("Vampire", FORCE_NUM, LOOT_COINS_NUM, DAMAGE_NUM) {}