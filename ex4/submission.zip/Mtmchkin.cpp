#include <string>
#include "Mtmchkin.h"
#include <fstream>
#include <iostream>
#include <deque>

#define MINIMUM_NUM_CARDS 5
#define MIN_NAME_LENGTH 1
#define MAX_NAME_LENGTH 15
#define MIN_PLAYERS_AMOUNT 2
#define MAX_PLAYERS_AMOUNT 6

Mtmchkin::Mtmchkin(const std::string fileName) :

        m_cardsQueue(),
        m_playersQueue(),
        m_winners(),
        m_losers(),
        m_round(0) //Before first round
{
    printStartGameMessage();
    std::ifstream file;
    file.open(fileName);
    if (!file) {
        throw DeckFileNotFound("Deck File Error: File not found");
    }
    checkValidFile(fileName);
    std::string line;
    while (!file.eof()) {
        getline(file, line);
        if (chekValidCardName(line)) {
            addCardToQueue(line);
        }
    }

    int numPlayers = ValidNumPlayers(); //beginning of the game - input check
    while (numPlayers > 0) { //adding players to the playerQueue
        printInsertPlayerMessage();
        std::string character, nameOfPlayer;
        std::cin >> nameOfPlayer >> character;
        ValidInput(nameOfPlayer, character);
        if (addPlayerToQueue(nameOfPlayer, character)) {
            numPlayers--;
        }
    }
}


///////////////////////////////////Functions of cards queue from constructor//////////////////////////////////

bool Mtmchkin::checkValidFile(const std::string &fileName) {
    int counter = 0;
    std::ifstream file;
    std::string line;
    file.open(fileName);
    if (file.is_open()) {
        while (!file.eof()) {
            if (getline(file, line)) {
                if (!(chekValidCardName(line))) {
                    throw DeckFileFormatError("Deck File Error: File format error in line ", counter + 1);
                }
                counter++;
            }
        }
    }
    if (counter < MINIMUM_NUM_CARDS) {
        throw DeckFileInvalidSize("Deck File Error: Deck size is invalid");
    }
    return true;
}

bool Mtmchkin::addCardToQueue(std::string& name) {
    if (name == "Goblin") {
        std::unique_ptr<Card> goblin(new Goblin());
        m_cardsQueue.push(std::move(goblin));
        return true;
    } else if (name == "Vampire") {
        std::unique_ptr<Card> vampire(new Vampire());
        m_cardsQueue.push(std::move(vampire));
        return true;
    } else if (name == "Dragon") {
        std::unique_ptr<Card> dragon(new Dragon());
        m_cardsQueue.push(std::move(dragon));
        return true;
    } else if (name == "Merchant") {
        std::unique_ptr<Card> merchant(new Merchant());
        m_cardsQueue.push(std::move(merchant));
        return true;
    } else if (name == "Treasure") {
        std::unique_ptr<Card> treasure(new Treasure());
        m_cardsQueue.push(std::move(treasure));
        return true;
    } else if (name == "Pitfall") {
        std::unique_ptr<Card> pitfall(new Pitfall());
        m_cardsQueue.push(std::move(pitfall));
        return true;
    } else if (name == "Barfight") {
        std::unique_ptr<Card> barfight(new Barfight());
        m_cardsQueue.push(std::move(barfight));
        return true;
    } else if (name == "Fairy") {
        std::unique_ptr<Card> fairy(new Fairy());
        m_cardsQueue.push(std::move(fairy));
        return true;
    }
    return false;// return exception
}

bool Mtmchkin::chekValidCardName(std::string& name) {
    if ((name == "Goblin") || (name == "Vampire") || (name == "Dragon") || (name == "Merchant") ||
        (name == "Treasure") || (name == "Pitfall") || (name == "Barfight") || (name == "Fairy")) {
        return true;
    }
    return false;
}

///////////////////////////////////Functions of players queue from constructor//////////////////////////////////

void Mtmchkin::ValidInput(std::string& name, std::string& character) const {
    int countValidInput = 0;
    while (countValidInput < 2)
    {
        countValidInput = 0;
        if (!ValidNameLength(name)) {
            printInsertPlayerMessage();
            std::cin >> name >> character;
        } else {
            countValidInput++;
            if (!checkCharacter(character)) {
                printInvalidClass();
                std::cin >> name >> character;
            } else
                countValidInput++;
        }
    }
}

bool Mtmchkin::ValidNameLength(std::string& name) const
{
    return (name.length() < MAX_NAME_LENGTH && name.length() > MIN_NAME_LENGTH);
}

int Mtmchkin::ValidNumPlayers() {

    int numPlayers;
    printEnterTeamSizeMessage();
    while ((!(std::cin >> numPlayers)) || numPlayers < MIN_PLAYERS_AMOUNT || numPlayers > MAX_PLAYERS_AMOUNT  ) {
        std::cin.clear();
        std::cin.ignore();
        printInvalidTeamSize();
        printEnterTeamSizeMessage();
    }
    return numPlayers;
}

bool Mtmchkin::checkCharacter (std::string& character) const
{
    return (character == "Wizard" || character == "Rogue" || character == "Fighter");
}

bool Mtmchkin::addPlayerToQueue(std::string& name, std::string& character) {

    if (character == "Wizard") {
        try {
            std::unique_ptr<Player> wizard(new Wizard(name));
            m_playersQueue.push_back(std::move(wizard));
        }
        catch (const std::bad_alloc &e) {
            std::cerr << "Out of memory: " << e.what() << std::endl;
            return false;
        }
        return true;

    } else if (character == "Fighter") {
        try {
            std::unique_ptr<Player> fighter(new Fighter(name));
            m_playersQueue.push_back(std::move(fighter));
        }
        catch (const std::bad_alloc &e) {
            std::cerr << "Out of memory: " << e.what() << std::endl;
            return false;
        }
        return true;

    } else if (character == "Rogue") {
        try {

            std::unique_ptr<Player> rogue(new Rogue(name));
            m_playersQueue.push_back(std::move(rogue));
        }
        catch (const std::bad_alloc &e) {
            std::cerr << "Out of memory: " << e.what() << std::endl;
            return false;
        }
        return true;
    } else {
        printInvalidClass();
    }
    return false;
}

///////////////////////////////////Main functions of Mtmchkin Class//////////////////////////////////

void Mtmchkin::playRound()
{
    if (m_round > MAX_NUMBER_OF_ROUNDS)
    {
        throw RoundLimit("You have reached the max round");
    }
    printRoundStartMessage((++m_round));
    int lengthOfQueue = (int)m_playersQueue.size();
    for (int i = 0; i < lengthOfQueue; i++)
    {
        printTurnStartMessage(m_playersQueue.front()->getName());
        std::unique_ptr<Player> currPlayer = std::move(m_playersQueue.front());
        m_playersQueue.pop_front();

        std::unique_ptr<Card> currCard = std::move(m_cardsQueue.front());
        m_cardsQueue.pop();
        currCard->playCard(currCard, currPlayer);
        if (currPlayer->hasWon()) {
          m_winners.push_back(std::move(currPlayer));
        } else if (currPlayer->hasLost()) {
           m_losers.push_back(std::move(currPlayer));
        } else {
            m_playersQueue.push_back(std::move(currPlayer));
            //if player hasn't won or lost, add him back to the deque
        }
        m_cardsQueue.push(std::move(currCard));
        if (isGameOver()) {
            printGameEndMessage();
            //   printLeaderBoard(); /////////////////צריך?
        }
    }
}

bool Mtmchkin::isGameOver() const {

    if (m_playersQueue.empty()) {
        return true;
    }
    return false;
}

int Mtmchkin::getNumberOfRounds() const {
    return m_round;
}

void Mtmchkin::printLeaderBoard() const {
    printLeaderBoardStartMessage();
    int j = 1;
    for (unsigned int i = 0; i < m_winners.size(); i++) {
        printPlayerLeaderBoard(j, *(m_winners.at(i)));
        j++;
    }

    for (std::unique_ptr <Player> const &it: m_playersQueue) {
        printPlayerLeaderBoard(j, *it);
        j++;
    }

    for (int i = (int)m_losers.size(); i > 0; i--) {
        printPlayerLeaderBoard(j,*( m_losers.at(i - 1)));
        j++;
    }
}
