#include <iostream>
#include "Mtmchkin.h"

int main() {
Mtmchkin game("deck.txt");
    return 0;
}
