#ifndef PLAYER_H_GOBLIN_H
#define PLAYER_H_GOBLIN_H
#include "BattleCards.h"
#include "Card.h"

class Goblin : public BattleCards {
public:
    Goblin();
    ~Goblin() override = default;
    };

#endif //PLAYER_H_GOBLIN_H
