#include "Gang.h"

Gang::Gang(std::vector<std::string> m_monsters) :
    Card("Gang"),
    m_gang()
{
    createGangCard(m_monsters);
}

void Gang::createGangCard(std::vector<std::string> &m_monsters) {

    for (unsigned int i = 0; i < m_monsters.size(); i++) {
        if (m_monsters[i] == "Goblin") {
            try {
                std::unique_ptr<BattleCards> goblin(new Goblin());
                m_gang.push_back(std::move(goblin));
            }
            catch (const std::bad_alloc &e) {
                std::cerr << "Out of memory: " << e.what() << std::endl;

            }
        }
        else if (m_monsters[i] == "Vampire") {
            try {
                std::unique_ptr<BattleCards> vampire(new Vampire());
                m_gang.push_back(std::move(vampire));
            }
            catch (const std::bad_alloc &e) {
                std::cerr << "Out of memory: " << e.what() << std::endl;

            }
        }
        else if (m_monsters[i] == "Dragon") {
            try {
                std::unique_ptr<BattleCards> dragon(new Dragon());
                m_gang.push_back(std::move(dragon));
            }
            catch (const std::bad_alloc &e) {
                std::cerr << "Out of memory: " << e.what() << std::endl;

            }
        }
    }
}

void Gang::printInheritance(std::ostream& os) const {
    os << "The members of the gang are: " << std::endl;
    for (unsigned int i = 0; i < m_gang.size(); i++) {
        m_gang.at(i)->printInheritance(os);
    }
    os << "End gang" << std::endl;
    printEndOfCardDetails(os);
}

bool Gang::playCard(std::unique_ptr<Player> &player, bool gangMode, bool hasWon) {
    for (unsigned int i = 0; i < m_gang.size(); i++) {
        if (m_gang.at(i)->playCard(player, gangMode, hasWon)) {
            continue;
        }
        else {
            hasWon = false;
        }
    }
    if (hasWon) {
       player->levelUp();
       printWinBattle(player->getName(), m_name);
    }
    return true;
}