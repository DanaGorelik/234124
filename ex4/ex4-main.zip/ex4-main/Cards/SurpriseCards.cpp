#include "SurpriseCards.h"

SurpriseCards::SurpriseCards(std::string name, int hp) :
        Card(name),
        m_hp(hp)
{}

