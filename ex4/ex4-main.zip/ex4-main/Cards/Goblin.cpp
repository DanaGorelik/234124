#include "Goblin.h"
#define FORCE_NUM 6
#define LOOT_COINS_NUM 2
#define DAMAGE_NUM 10


Goblin::Goblin() :
        BattleCards("Goblin", FORCE_NUM, LOOT_COINS_NUM, DAMAGE_NUM) {}