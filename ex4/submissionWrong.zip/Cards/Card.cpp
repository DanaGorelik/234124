#include "Card.h"

Card::Card(std::string name) :
        m_name(name)
{}

//std::ostream& operator<<(std::ostream  &os, const Card& card) {
//    printCardDetails(os, card.m_name);
//    if (card.getName()=="Vampire") {
//        printMonsterDetails(os, 10, 10, 2, false);
//    }
//    else if (card.getName() == "Goblin") {
//            printMonsterDetails(os, 6, 10, 2, false);
//        } else if (card.getName() == "Dragon") {
//            printMonsterDetails(os, 25, -1, 1000, true);
//        }
//    printEndOfCardDetails(os);
//    return os;
//}

std::string Card::getName() const {
    return m_name;
}

std::ostream& operator<<(std::ostream &os, const Card& card) {
    card.printInheritance(os);
    return os;
}



