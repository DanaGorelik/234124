#ifndef PLAYER_H_VAMPIRE_H
#define PLAYER_H_VAMPIRE_H

#include "BattleCards.h"

class Vampire : public BattleCards {
public:
    Vampire();
    ~Vampire() override = default;

};

#endif //PLAYER_H_VAMPIRE_H
