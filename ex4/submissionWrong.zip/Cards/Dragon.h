#ifndef PLAYER_H_DRAGON_H
#define PLAYER_H_DRAGON_H

#include "BattleCards.h"

class Dragon : public BattleCards {
public:
    Dragon();
    ~Dragon() override = default;
};

#endif //PLAYER_H_DRAGON_H
