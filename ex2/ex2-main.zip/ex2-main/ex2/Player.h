//
// Created by DELL on 03-May-22.
//

#ifndef EX2_PLAYER_H
#define EX2_PLAYER_H
#include <string>

class Player {

public:
    static const int DEFAULT_HP = 100;
    static const int DEFAULT_FORCE = 5;
    static const int START_M_LEVEL = 1;
    static const int START_M_COINS = 0;
    static const int DEFAULT_M_FORCE = 5;
    static const int DEFAULT_M_MAX_HP = 100;
    static const int MAX_LEVEL = 10;

    explicit Player(std::string name, int maxHP = DEFAULT_HP, int force = DEFAULT_FORCE);
    ~Player();
    Player(const Player&);
    void printInfo() const;
    void levelUp();
    int getLevel() const;
    void buff(int addForce);
    void heal(int addHP);
    void damage(int damageHP);
    bool isKnockedOut() const;
    void addCoins(int coinsNum);
    bool pay(int coinsNum);
    int getAttackStrength() const;

private:
    std::string m_name;
    int m_level;
    int m_force;
    int m_maxHP;
    int m_HP;
    int m_coins;
};

#endif //EX2_PLAYER_H