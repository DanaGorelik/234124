#include <iostream>
#include "Player.h"
#include <string>
using namespace std;
int main() {

        Player player1("Efrat",150,2);  //Efrat has 150 max HP and 2 points of force.
        Player player2("Gandalf",300);  //Gandalf has 300 max HP and 5 points of force.
        Player player3("Daniel"); //Gandalf has 100 max HP and 5 points of force.
        player2.printInfo();
        player2.levelUp();
        player2.buff(1);
        player2.printInfo();
        if (player2.getLevel() != 2)
            cout << "Problem with level" << endl;

        player1.printInfo();
        player2.printInfo();

    return 0;
}
